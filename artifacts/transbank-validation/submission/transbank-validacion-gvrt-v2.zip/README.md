# Screenshots

Si tu visor no abre bien los `PNG`, usa las copias `JPG` dentro de [jpg](/Users/hh/tprt/artifacts/transbank-validation/submission/jpg).

## Archivos principales

- Aprobada Visa PNG: [22-approved-confirmation-fixed.png](/Users/hh/tprt/artifacts/transbank-validation/submission/22-approved-confirmation-fixed.png)
- Aprobada Visa JPG: [22-approved-confirmation-fixed.jpg](/Users/hh/tprt/artifacts/transbank-validation/submission/jpg/22-approved-confirmation-fixed.jpg)
- Rechazada Mastercard PNG: [23-rejected-confirmation-fixed.png](/Users/hh/tprt/artifacts/transbank-validation/submission/23-rejected-confirmation-fixed.png)
- Rechazada Mastercard JPG: [23-rejected-confirmation-fixed.jpg](/Users/hh/tprt/artifacts/transbank-validation/submission/jpg/23-rejected-confirmation-fixed.jpg)
- Aprobada Redcompra PNG: [28-redcompra-confirmation.png](/Users/hh/tprt/artifacts/transbank-validation/submission/28-redcompra-confirmation.png)
- Aprobada Redcompra JPG: [28-redcompra-confirmation.jpg](/Users/hh/tprt/artifacts/transbank-validation/submission/jpg/28-redcompra-confirmation.jpg)
- Aprobada AMEX PNG: [32-amex-confirmation.png](/Users/hh/tprt/artifacts/transbank-validation/submission/32-amex-confirmation.png)
- Aprobada AMEX JPG: [32-amex-confirmation.jpg](/Users/hh/tprt/artifacts/transbank-validation/submission/jpg/32-amex-confirmation.jpg)
